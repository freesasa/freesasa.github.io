#!/bin/bash
python python/test.py