#ifndef TOOLS_H
#define TOOLS_H

int
float_eq(double a, double b, double tolerance);

void
set_fail_after(int freq);

#endif
