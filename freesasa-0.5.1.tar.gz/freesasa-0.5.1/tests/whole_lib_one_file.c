// By including this file we get access to static functions
#include <freesasa.c>
#include <structure.c>
#include <nb.c>
#include <classify.c>
#include <sasa_lr.c>
#include <sasa_sr.c>
#include <coord.c>
#include <pdb.c>
#include <util.c>
#include <user_config.c>
#include <selection.c>

