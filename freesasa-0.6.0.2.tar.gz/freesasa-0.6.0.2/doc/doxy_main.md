FreeSASA
========

These pages document the 
    
  - @ref CLI
  - @ref API "FreeSASA C API"
  - @ref Python "FreeSASA Python interface"
  - @ref Config-file
  - @ref Geometry

The library is licensed under [GPLv3](GPL.md).

Installation instructions can be found in the [README](README.md) file.

@page CLI Command-line Interface

Building FreeSASA creates the binary `freesasa`, which is installed by
`make install`. Calling

    $ freesasa -h

displays a help message listing all options. The following text
explains how to use most of them.

@section CLI-Default Run using defaults

In the following we will use the PDB structure 1UBQ as
an example. To run a simple SASA calculation using default parameters,
simply type:

    $ freesasa 1ubq.pdb

This generates the following output

    PARAMETERS
    input             : tests/data/1ubq.pdb
    n_atoms           : 602
    algorithm         : Lee & Richards
    probe-radius      : 1.400
    n_thread          : 2
    n_slices_per_atom : 20
    
    RESULTS
    Total   :    4804.06
    Apolar  :    2299.84
    Polar   :    2504.22
    
The results are all in the unit Ångström-squared. 

@section parameters Changing parameters

If higher precision is needed, the command

    $ freesasa -n 100 1ubq.pdb

specifies that the calculation should use 100 slices per atom instead of
the default 20. The command

    $ freesasa --shrake-rupley -n 200 --probe-radius 1.2 --n-threads 4 1ubq.pdb

instead calculates the SASA using Shrake & Rupley's algorithm with 200
test points, a probe radius of 1.2 Å, using 4 parallel threads to
speed things up.

If the user wants to use their own atomic radii the command 

    $ freesasa --config-file <file> 1ubq.pdb

Reads a configuration from a file and uses it to assign atomic
radii. The program will halt if it encounters atoms in the PDB input
that are not present in the configuration. See @ref Config-file for
instructions how to write a configuration.

@section Output Other output types

To calculate the SASA of each residue in
the sequence, or each residue type, the commands

    $ freesasa --foreach-residue --no-log 1ubq.pdb
    SEQ A    1 MET :   54.39
    SEQ A    2 GLN :   74.21
    SEQ A    3 ILE :    0.00
    ...

and

    $ freesasa --foreach-residue-type --no-log 1ubq.pdb
    RES ALA :     120.08
    RES ARG :     540.12
    RES ASN :     166.45
    ...

to stdout respectively (`--no-log` suppresses the standard log
message). 

The command-line interface can also be used as a PDB filter:

    $ cat 1ubq.pdb | freesasa --no-log --print-as-B-values 
    ATOM      1  N   MET A   1      27.340  24.430   2.614  1.64 19.52
    ATOM      2  CA  MET A   1      26.266  25.413   2.842  1.88 15.53
    ATOM      3  C   MET A   1      26.913  26.639   3.531  1.61  0.26
    ...

The output is a PDB-file where the temperature factors have been
replaced by SASA values (last column), and occupancy numbers by the
radius of each atom (second to last column).

Only the atoms and models used in the calculation will be present in
the output (see @ref Input for how to modify this).

To generate all three results at the same time and write them to
separate files, run

    $ freesasa --residue-file=1ubq.seq --residue-type-file=1ubq.res --B-value-file=1ubq.b 1ubq.pdb

@section CLI-select Selecting groups of atoms

The option `--select` can be used to define groups of atoms whose
integrated SASA we are interested in. It uses a subset of the Pymol
`select` command syntax, see @ref Selection for full
documentation. The following example shows how to calculate the sum of
exposed surface areas of all aromatic residues and of ASP and ASN

    $ freesasa --select "aromatic, resn phe+tyr+trp+his+pro" --select "asx, resn asp+asn" 1ubq.pdb
    ...
    SELECTIONS
    freesasa: warning: Found no matches to resn 'TRP', typo?
    aromatic :     360.38
    asx :     559.46

This command adds a 'Selection:' section at the end of the
output. This particular protein did not have any TRP residues, hence
the warning (written to stderr). The warning can be supressed with the
flag `-w`.

@section Input PDB input

@subsection Hetatom-hydrogen Including extra atoms

The user can ask to include hydrogen atoms and HETATM entries in the
calculation using the options `--hydrogen` and `--hetatm`. In both
cases adding unknown atoms will emit a warning for each atom. This can
either be amended by using the flag '-w' to suppress warnings, or by
using a custom classifier so that they are recognized (see @ref
Config-file).

@subsection Halt-skip Skipping unknown atoms

By default FreeSASA guesses the element of an unknown atom and uses
that elements VdW radius. If this fails the radius is set to 0 (and
hence the atom will not contribute to the calculated area). Users can
request to either skip unknown atoms completely (i.e. no guessing) or
to halt when unknown atoms are found and exit with an error. This is
done with the option `--unknown` which takes one of the three
arguments `skip`, `halt` or `guess` (default). Whenever an unknown
atom is skipped or its radius is guessed a warning is printed to
stderr.

@subsection Chains-models Separating and joining chains and models

If a PDB file has several chains and/or models, by default all chains
of the first model are used, and the rest of the file is ignored. This
behavior can be modified using the following options 

  - `--join-models`: Joins all models in the input into one large
    structure. Useful for biological assembly files were different
    locations of the same chain in the oligomer are represented by
    different MODEL entries.

  - `--separate-models`: Calculate SASA separately for each model in
    the input. Useful when the same file contains several
    conformations of the same molecule.

  - `--separate-chains`: Calculate SASA separately for each chain in
    the input. Can be joined with `--separate-models` to calculate
    SASA of each chain in each model.

  - `--chain-groups`: Define groups of chains that should be treated
    as separate entities, can be repeated. If we for example have a
    tetramer with chains ABCD and want to know how much surface was
    buried when the dimers AB and CD were joined, we can use the option
    `--chain-groups=AB+CD`. The output will contain the SASA for the
    full molecule and one entry for each of the pairs of chains AB and
    CD. Can not be combined with `--separate-chains`.

@page API FreeSASA API

@section Basic-API Basics

The API is found in the header [freesasa.h](freesasa_8h.html) and this
is the only header installed by `make install`. The other source-files
and headers in the repository are for internal use, and are not
present here, but are thoroughly documented in the source itself.

To calculate the SASA of a structure, there are two main options:

1. Initialize a structure from a PDB-file, using either the default
   classifier or a custom one to determine the radius of each atom,
   and then run the calculation.

2. Provide an array of cartesian coordinates and an array containing
   the radii of the corresponding atoms to freesasa_calc_coord().

@subsection API-PDB Calculate SASA for a PDB file

The following explains how to use FreeSASA to calculate the SASA of a
fictive PDB file (1abc.pdb). At each step one or more error checks
should have been done, but these are ignored here for brevity. See
the documentation of each function to see what errors can occur.
Default parameters are used at every step, the section @ref
Customizing explains how to configure the calculations.

@subsubsection API-Read-PDB Open PDB file

The function freesasa_structure_from_pdb() reads the atom coordinates
from a PDB file and assigns a radius to each atom. The second and
third arguments can be changed to use a custom freesasa_classifier to
define radii and to specify options for what to include in the PDB
file, respectively.

~~~{.c}
    FILE *fp = fopen("1abc.pdb");
    freesasa_structure *structure = freesasa_structure_from_pdb(fp, NULL, 0);
~~~

@subsubsection API-Calc Perform calculation and get total SASA

Next we use freesasa_calc_structure() to calculate SASA using the
structure we just generated, and then print the total area. The argument
`NULL` means use default freesasa_parameters.

~~~{.c}
    freesasa_result *result = freesasa_calc_structure(structure, NULL);
    printf("Total area: %f A2\n",result->total);
~~~

@subsubsection API-Classes Get polar and apolar area

We are commonly interested in the polar and apolar areas of a
molecule, this can be calculated by freesasa_result_classify(). Again,
passing a NULL freesasa_classifier uses the default. To get other
classes of atoms we can either define our own classifier, or use
freesasa_select_area() defined in the next section. The return type
freesasa_strvp contains arrays of strings and values describing the
different classes, as illustrated below.

~~~{.c}
    freesasa_strvp *class_area = freesasa_result_classify(result, structure, NULL);
    for (int i = 0; i < class_area->n; ++i)
        printf("%s: %f A2\n", class_area->string[i], class_area->value[i]);
~~~

@see @ref Classification

@subsubsection API-Select Get area of custom groups of atoms

Groups of atoms can be defined using freesasa_select_area(), which
takes a selection definition uses a subset of the Pymol select syntax

~~~{.c}
    double area;
    char name[FREESASA_MAX_SELECTION_NAME+1];
    freesasa_select_area("aromatic, resn phe+tyr+trp+his+pro",
                         name, &area, structure, result);
    printf("Area of selection '%s': %f A2\n", name, area);
~~~

@see @ref Selection.

@subsection Coordinates

If users wish to supply their own coordinates and radii, these are
accepted as arrays of doubles passed to the function
freesasa_calc_coord(). The coordinate-array should have size 3*n with
coordinates in the order `x1,y1,z1,x2,y2,z2,...,xn,yn,zn`.

~~~{.c}
    double coord[] = {/* x */ 1.0, /* y */ 2.0, /* z */ 3.0};
    double radius[] = {2.0};
    freesasa_result *result = freesasa_calc_coord(coord, radius, 1, NULL);
~~~

@subsection Error-handling

The principle for error handling is that unpredictable errors should
not cause a crash, but rather allow the user to exit gracefully or
make another attempt. Therefore, errors due to user or system
failures, such as faulty parameters, malformatted config-files, I/O
errors or out of memory errors, are reported through return values,
either ::FREESASA_FAIL or ::FREESASA_WARN, or by NULL pointers,
depending on the context. See the documentation for the individual
functions. If memory allocation fails as much memory as possible is
released. To the extent that it's possible to emulate system failures
like this, they have been verified to not cause aborts or seg-faults
(see the tests/ directory) in any part of the code.

Errors that are attributable to programmers using the library, such as
passing null pointers where not allowed, are checked by asserts.

@subsection Thread-safety 

The only global state the library stores is the verbosity level (set
by freesasa_set_verbosity()) and the pointer to the error-log
(defaults to `stderr`, can be changed by freesasa_set_err_out()). 

It should be clear from the documentation when the other
functions have side effects such as memory allocation and I/O, and
thread-safety should generally not be an issue (to the extent that
your C library has threadsafe I/O and dynamic memory allocation). The
SASA calculation itself can be parallelized by passing a
::freesasa_parameters struct with ::freesasa_parameters.n_threads set
to a value > 1 (default is 2) to freesasa_calc_structure() or
freesasa_calc_coord(). This only gives a significant effect on
performance for large proteins or at high precision, and because not
all steps are parallelized it is usually not worth it to go beyond 2
threads.

@section Customizing Customizing behavior

The types ::freesasa_parameters and ::freesasa_classifier can be used
to change the parameters of the calculations. Users who wish to use
the defaults can pass NULL wherever pointers to these are requested.

@subsection Parameters Parameters

Changing parameters is done by passing a ::freesasa_parameters object
with the desired values. It can be initialized to default by

~~~{.c}
freesasa_parameters param = freesasa_default_parameters;
~~~

To allow the user to only change the parameters that are non-default.

The following call would run a high precision Shrake & Rupley
calculation with 10000 test points

~~~{.c}
param.alg = FREESASA_SHRAKE_RUPLEY;
param.lee_richards_n_slices = 10000;
freesasa_result *result = freesasa_calc_structure(structure,radii,param);
~~~

@subsection Classification Specifying atomic radii and classes

The type ::freesasa_classifier has function pointers to functions that
take residue and atom names as argument (pairs such as "ALA","CA"),
and returns a radius or a class (polar, apolar, etc). The classifier
can be passed to freesasa_structure_from_pdb(),
freesasa_structure_array() or freesasa_structure_add_atom_wopt() to
customize the radii assigned to atoms, which can then be used to
calculate the SASA of the structure. It can also be used in
freesasa_result_classify() to get the SASA integrated over the
different classes of atoms, i.e. the SASA of all polar atoms, etc.

Users of the API can provide their own classification by writing their
own functions and providing them via a ::freesasa_classifier object. A
classifier-configuration can also be read from a file using
freesasa_classifier_from_file() (see @ref Config-file).

The default classifier is available through the const variable
::freesasa_default_classifier. This uses the radii, defined in the
paper by Tsai et al. ([JMB 1999, 290:
253](http://www.ncbi.nlm.nih.gov/pubmed/10388571)) for the standard
amino acids (20 regular plus SEC, PYL, ASX and GLX), for some capping
groups (ACE/NH2) and the nucleic acids. If the element can't be
determined or is unknown, a negative radius is returned. It classes
all carbons as *apolar* and all other known atoms as *polar*. 

Early versions of FreeSASA used the atomic radii by Ooi et al. ([PNAS
1987, 84: -3086](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC304812/),
this classifier is still available through freesasa_classifier_oons().

The default behavior of freesasa_structure_from_pdb(),
freesasa_structure_array(), freesasa_structure_add_atom() and
freesasa_structure_add_atom_wopt() is to first try the default
classifier and then guess the radius if necessary (emitting warnings
if this is done, uses VdW radii defined by [Mantina et al. J Phys Chem
2009,
113:5806](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3658832/)).

See the documentation for these functions for what
parameters to use to change the default behavior.

@page Config-file Classifier configuration files

The configuration files read by freesasa_classifier_from_file() or the
command-line option `-c` should have two sections: `types:` and
`atoms:`. 

The types-section defines what types of atoms are available
(aliphatic, aromatic, hydroxyl, ...), what the radius of that type is
and what class a type belongs to (polar, apolar, ...). The types are
just shorthands to associate an atom with a given combination of class
and radius. The user is free to define as many types and classes as
necessary.

The atoms-section consists of triplets of residue-name, atom-name (as
in the corresponding PDB entries) and type. A prototype file would be

~~~
types:
C_ALIPHATIC 2.00 apolar
C_AROMATIC  1.75 apolar
N 1.55 polar

atoms:
ANY N  N             
ANY CA C_ALIPHATIC
ANY CB C_ALIPHATIC

ARG CG C_ALIPHATIC

PRO CB C_AROMATIC  # overrides ANY CB
~~~

The residue type `ANY` can be used for atoms that are the same in all
or most residues (such as backbone atoms). If there is an exception
for a given amino acid this can be overridden as is shown for `PRO CB`
in the example.

A few example configurations are available in the directory
[share/](https://github.com/mittinatten/freesasa/tree/master/share). The
configuration-file
[protor.config](https://github.com/mittinatten/freesasa/tree/master/share/protor.config)
is a copy of the default classifier, and can be used to add extra
atoms that need to be classified, while keeping the defaults for the
standard residues (also see the file
[scripts/chemcomp2config.pl](https://github.com/mittinatten/freesasa/tree/master/scripts/)
for instructions on how to generate configurations for new chemical
components semi-automatically). If something common is missing in the
default classifier, [create an
issue](https://github.com/mittinatten/freesasa/issues) on Github so
that it can be added.

FreeSASA also ships with some configuration-files that mimic other
popular programs, such as
[NACCESS](https://github.com/mittinatten/freesasa/tree/master/share/naccess.config)
and
[DSSP](https://github.com/mittinatten/freesasa/tree/master/share/dssp.config).

@page Selection Selection syntax

FreeSASA uses a subset of the Pymol select commands to give users an
easy way of summing up the SASA of groups of atoms. This is done by
the function freesasa_select_area() in the C API,
freesasa.selectArea() in the Python interface and the option
`--select` for the command line tool. All commands are case
insensitive. A basic selection has a selection name, a property
selector and a list of arguments

    <selection-name>, <selector> <list>

For example

    aromatic, resn phe+tyr+trp+his+pro

Several selectors can be joined using boolean logic and parentheses,

    <selection-name>, (<s1> <l1>) and not (<s2> <l2> or <s3> <l3>)

where s1, s2 and s3 are selectors and l1, l2 and l3 are lists. The
operator `and` has precedence over `or`, so the second parentheses is
necessary but not the first, in the example above. The selection name
has to start with a letter, but it can include numbers and
underscores. The name can't be longer than
::FREESASA_MAX_SELECTION_NAME characters.

The following property selectors are supported

- `resn` Residue names like "ala", "arg", "du", etc 
- `resi` Residue index (positive integers)
- `chain` Chain labels (single characters)
- `name` Atom names, such as "ca", "c", "oxt", etc
- `symbol` Element symbols, such as "C", "O", "Se", "Fe", etc.

A list of residues can be selected using

    resn ala+val+leu+ile+met

and similarly for the other four selectors. In addition `resi` and
`chain` support ranges

    resi 1-10
    resi 1-10+20-30+35
    chain A+C-E

Combining ranges with plus signs, as in the two last lines, is not
allowed in Pymol but supported by FreeSASA.

If a selection list contains elements not found in the molecule that
is analyzed, a warning is printed and that part of the list does not
contribute to the selection. Not finding an a list element can be
because it specifies a residue that does not exist in the particular
molecule, or because of typos. The selector does not keep a list of
valid elements, residue names, etc.

@page Python Python interface

If Python is enabled using 
    
    $ ./configure --enable-python-bindings

Cython is used to build Python bindings for FreeSASA, and `make
install` will install them.

Below follow some illustrations of how to use the package, see the
@ref freesasa "package documentation" for details.

@section Python-basics Basic calculations

Using defaults everywhere a simple calculation can be carried out as
follows (assuming the PDB structure 1UBQ is available)

~~~{.py} 
import freesasa

structure = freesasa.Structure("1ubq.pdb")
result = freesasa.calc(structure)
area_classes = freesasa.classifyResults(result,structure)

print "Total : %.2f A2" % result.totalArea()
for key in area_classes:
    print key, ": %.2f A2" % area_classes[key]
~~~

Which would give the following output

    Total : 4834.72 A2
    Polar : 2515.82 A2
    Apolar : 2318.90 A2

The following does a high precision L&R calculation

~~~{.py}
result = freesasa.calc(structure,
                       freesasa.Parameters({'algorithm' : freesasa.LeeRichards,
                                            'n-slices' : 100}))
~~~

Using the results from a calculation we can also integrate SASA over a selection of
atoms, using a subset of the Pymol selection syntax (see @ref Selection):

~~~{.py}
selections = freesasa.selectArea(('alanine, resn ala','r1_10, resi 1-10'), 
                                 structure, result)
for key in selections:
    print key, ": %.2f A2" % selections[key]
~~~
which gives the output

    alanine : 118.35 A2
    r1_10 : 643.01 A2


@section Python-classification Customizing atom classification

This uses the NACCESS parameters (the file 'naccess.config' is
available in the share/ directory of the repository).

~~~{.py}
classifier = freesasa.Classifier("naccess.config")
structure = freesasa.Structure("1ubq.pdb",classifier) 
result = freesasa.calc(structure)
area_classes = freesasa.classifyResults(result,structure,classifier)
~~~

Classification can be customized also by extending the Classifier
interface. The code below is an illustration of a classifier that
classes Nitrogens separately, and assigns radii based on element only
(and crudely).

~~~{.py}
import freesasa
import re

class DerivedClassifier(Classifier):
    def classify(self,residueName,atomName):
        if re.match('\s*N',atomName):
            return 'Nitrogen'
        return 'Not-nitrogen'

    def radius(self,residueName,atomName):
        if re.match('\s*N',atomName): # Nitrogen 
            return 1.6
        if re.match('\s*C',atomName): # Carbon
            return 1.7
        if re.match('\s*O',atomName): # Oxygen
            return 1.4
        if re.match('\s*S',atomName): # Sulfur
            return 1.8    
    return 0;                     # everything else (Hydrogen, etc)

classifier = DerivedClassifier()

# use the DerivedClassifier to calculate atom radii
structure = freesasa.Structure("1ubq.pdb",classifier)
result = freesasa.calc(structure)

# use the DerivedClassifier to classify atoms
area_classes = freesasa.classifyResults(result,structure,classifier)
~~~

Of course, this example is somewhat contrived, if we only want the
integrated area of Nitrogen atoms, the simpler choice would be
~~~{.py}
    selection = freesasa.selectArea('nitrogen, symbol n', structure, result)
~~~

However, extending freesasa.Classifier, as illustrated above, allows
classification to arbitrary complexity and also lets us redefine the
radii used in the calculation.

@page Geometry Geometry of Lee & Richards' algorithm

This page explains the geometry of the calculations in L&R
and can be used to understand the source code. As far as possible the
code uses similar notation to the formulas here.

We will use the following notation: An atom \f$i\f$ has a van der
Waals radius \f$r_i\f$, the rolling sphere (or *probe*) has radius
\f$r_\text{P}\f$ and when these are added we get an extended radius
\f$R_i = r_i + r_\text{P}\f$. The sphere of radius \f$R_i\f$ centered
at the position of atom \f$i\f$ represents the volume not accessible
to the center of the probe. The SASA for a molecule is then obtained
by calculating the non-buried surface area of the extended spheres.

The L&R algorithm calculates the surface area by slicing the
protein, calculating the length of the solvent exposed contours in
each slice and then adding up the length multiplied by the slice
thickness.

![Slice in atom](../fig/lnr_slice.svg)

Divide atom \f$i\f$ into \f$n\f$ slices, orthogonal to an arbitrary
axis, of thickness \f$\delta = 2R_i/n\f$. The position of the middle
of the slice along that axis is denoted \f$z\f$, and the center of
atom \f$i\f$, along the same axis, is at \f$z_i\f$. In each slice, the
atom is thus a circle of radius \f[R_i^\prime =
\sqrt{R_i^2-(z-z_i)^2}\,.\f] These circles are either completely
buried inside neighboring atoms, completely exposed, or partially
exposed.

![Overlap of circles](../fig/lnr_circles.svg)

The exposed arc lengths for each atom can be calculated exactly. For
each pair of atoms \f$i,j\f$, the distance between their centers
projected on the slice is \f$d_{ij}\f$ (independent of \f$z\f$). If
\f$d_{ij} > R_i^\prime + R_j^\prime\f$, there is no overlap. If
\f$d_{ij} < R_j^\prime - R_i^\prime\f$ circle \f$i\f$ is completely
inside \f$j\f$ (and the other way around). If \f$d_{ij}\f$ lies
between these two cases the angle of circle \f$i\f$ that is buried due
to circle \f$j\f$ is

\f[ \alpha = 2\arccos \bigl[({R_i^\prime}^2_{\,}
+ d_{ij}^2 - {R_{j}^\prime}^2_{\,})/(2R_i^\prime d_{ij})\bigr].  \f]

If the middle point of this arc on the circle is at an angle
\f$\beta\f$, the arc spans the interval
\f$[\beta-\alpha/2,\beta+\alpha/2]\f$. By adding up these arcs and
taking into account any overlap between them we get the total buried
angle \f$\gamma\f$ in this slices. The exposed arc angle for this atom
and slice is thus \f$2\pi-\gamma\f$ and the total SASA of that atom

\f[ A_i =R_i \delta \!\! \sum_{s\in\text{slices}} \!\!
\left[2\pi-\gamma_s\right]\,.  \f]

The angle is multiplied by \f$R_i\f$ (not \f$R_i^\prime\f$) to give
the area of a conical frustum circumscribing the sphere at the
slice. Finally, the total area \f$A\f$ is the sum of all \f$A_i\f$.

In FreeSASA, the L\&R SASA calculation begins by finding overlapping
spheres and storing the contacts in an adjacency list. It then
iterates through all the slices of each atom and checks for overlap
with adjacent atoms in each slice, and adds up the exposed arcs to
calculate the atom's contribution to the SASA of the slice. The
calculations for each atom are completely independent and can thus be
parallelized over an arbitrary number of threads, whereas the
calculation of adjacency lists has not been parallelized.